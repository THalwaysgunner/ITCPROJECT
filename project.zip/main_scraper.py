from project.scraper import Scraper


def main():
    scraper = Scraper()
    scraper.scrape_all()


if __name__ == '__main__':
    main()


